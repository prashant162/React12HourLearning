export const Ratings = [
{   image: "https://rukminim2.flixcart.com/image/832/832/xif0q/shoe/p/g/t/9-5g-846-9-campus-gry-d-gry-original-imagqtk99fan52yy.jpeg?q=70&crop=false",
    rateCount: 5,
    personCount: "10",
    description: "This is the primary view of the shoe",
    price: "$15.00 USA",
    showRatings: true,
    id: 1
},
{
    image: "https://rukminim2.flixcart.com/image/832/832/xif0q/shoe/c/o/p/9-5g-846-9-campus-gry-d-gry-original-imagqtk9jbehgywz.jpeg?q=70&crop=false",
    rateCount: 5,
    personCount: 20000,
    description: "This is the secondary view of the shoe",
    price: "$135.00 USA",
    showRatings: false,
    id: 2
},
{
    image: "https://rukminim2.flixcart.com/image/832/832/xif0q/shoe/q/7/5/9-5g-846-9-campus-gry-d-gry-original-imagqtk9kbrgs2hd.jpeg?q=70&crop=false",
        rateCount: 5,
        personCount: 10000000,
        description: "This is the sole view of the shoe",
        price: "$150.00 USA",
        showRatings: false,
        id: 3
},
{
    image: "https://rukminim2.flixcart.com/image/832/832/xif0q/shoe/d/6/s/9-5g-846-9-campus-gry-d-gry-original-imagqtk9wccjguge.jpeg?q=70&crop=false",
        rateCount: 5,
        personCount: 10000,
        description: "This is the side view of the shoe",
        price: "$155.00 USA",
        showRatings: true,
        id: 4
}
]