import React from "react";

export default function Stars(props){
    return(
        <div className="rating">
    <span>&#x2605;</span>
    <span>{props.rateCount}</span>
    <span>({props.personCount})</span>
  </div>
    )
}