import React from "react";

export default function Challenge(){
    const pokemon = ["Bulabsur", "Charmendar",  "Squirtle"];
    const withPTag = pokemon.map(pokmn => `<p>${pokmn}</p>`);
    console.log(withPTag);
}




