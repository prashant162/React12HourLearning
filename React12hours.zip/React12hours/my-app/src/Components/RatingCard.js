import React from "react";
import Stars from "./Starts";
import "../Styles/ratingCard.css"

export default function RatingCard(props){
    return(
        <>
        <div className="image-card">
  <img src={props.data.image} alt="Image Description" />
   {props.data.showRatings && <Stars rateCount={props.data.rateCount} personCount={props.data.personCount}/>}
  <div className="description">
    <p>{props.data.description}</p>
    <p className="pricefont">{props.data.price}</p>
  </div>
</div>
</>
    )
}

