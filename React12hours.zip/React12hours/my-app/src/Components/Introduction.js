import React from "react";

export default function Introduction(){
    const firstName = "Prashant";
    const lastName = "Tomar";
    const publicationDate = "30-March-2024";
    return(
        <>
         <h3>Author: {firstName} {lastName}</h3>
         <h5>publication Date: {publicationDate}</h5>
        </>
    )
}