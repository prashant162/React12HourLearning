import React from "react"
import reactLogo from "../Images/logo.svg"

export default function Header(){
    return(
      <ul>
        <li><a className="active" href="#home">Home</a></li>
        <li><a href="#news">News</a></li>
        <li><a href="#contact">Contact</a></li>
        <img className="logo-pull-right" src={reactLogo} width="75px"/>
    </ul>
    )
  }