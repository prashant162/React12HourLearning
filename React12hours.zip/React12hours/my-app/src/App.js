import React from "react";
import Header from "./Components/Header";
import Footer from "./Components/Footer";
import RatingCard from "./Components/RatingCard";
import Introduction from "./Components/Introduction";
//import Challenge from "./Components/Challenge";
import { Ratings } from "./Datasource/RatingData";

export default function App(){

  const ratingCards = Ratings.map(rate => {
    return <RatingCard 
    data={rate}
    key={rate.id} />
  })

    return (
    <>
      <Header />
      <Introduction />
      {ratingCards}
      <Footer />
    </>
    )
  }