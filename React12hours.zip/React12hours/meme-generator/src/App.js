import React from "react";
import Meme from "./Components/meme";
import Counter from "./Components/Counter";
import FlipBoolean from "./Components/FlipBoolean";
import ShowArray from "./Components/ArrayModifier";
import FaviourateCard from "./Components/FaviouriteCard";
import Box from "./Components/Box";
import BoxInfo from "./BoxData"
import Form from "./Components/Form";

export default function App(){
  const [flip, setFlip] = React.useState(BoxInfo);
  function handleBoxFlip(id){
    setFlip(function (prevBoxInfo){
      return prevBoxInfo.map(box => box.id == id ? {...box, on: !box.on} : box)
    })
  }
  let boxData = flip.map(box => <Box on={box.on} handleBoxClick={() => handleBoxFlip(box.id)} key={box.id}/>)
  return(
    <>
      <Meme />
      <hr />
      <Counter />
      <hr />
      <FlipBoolean />
      <hr />
      <ShowArray />
      <hr />
      <FaviourateCard />
      <hr />
      {boxData}
      <hr />
      <Form />
      <hr />
    </>
  )
}