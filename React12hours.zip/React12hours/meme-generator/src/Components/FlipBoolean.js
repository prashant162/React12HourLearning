import React from "react";

export default function FlipBoolean(){
    const [flipValue, setFilpValue] = new React.useState(true);
    function flipCurrentValue(){
        setFilpValue(function(prevValue){
            return !prevValue;
        })
    }
    return(
        <div style={{backgroundColor: "beige"}} onClick={flipCurrentValue}>
            <h1>{flipValue ? "Yes" : "No"}</h1>
        </div>
    )
}