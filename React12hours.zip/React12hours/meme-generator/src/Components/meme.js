import React from "react";
import MemeHeader from "./memeheader";
import "../Styles/Styles.css"
import MainMeme from "./mainmeme";

export default function Meme(){
    return(
        <div>
            <MemeHeader />
            <MainMeme />
        </div>
    )
}