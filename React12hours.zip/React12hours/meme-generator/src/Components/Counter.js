import React from "react";

export default function Counter(){
    const [result, setResult] = new React.useState(0);
    function handleIncreament(){
        setResult(function(prevValue){
            return prevValue + 1;

        })
    }
    function handleDecreament(){
        setResult(function(prevValue){
            return prevValue - 1;
        })
    }
    return(
        <div style={{backgroundColor: "bisque"}}>
            <div className="increament" onClick={handleIncreament}>+</div>
            <div className="counterResult">{result}</div>
            <div className="decreament" onClick={handleDecreament}>-</div>
        </div>
    )
}