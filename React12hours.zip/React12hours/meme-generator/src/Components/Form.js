import React from "react";

export default function Form(){
    const [firstName, setFirstName] = React.useState("");
    function handleFirstNameInput(event){
        return setFirstName(event.target.value);
    }
    return (
        <Form>
            <input type="text" placeholder="Enter the first name..." onChange={handleFirstNameInput}/>            
            <div>{firstName}</div>
        </Form>
    )
}