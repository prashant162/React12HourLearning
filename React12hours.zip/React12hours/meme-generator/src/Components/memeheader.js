import React from "react";
import memelogo from "../Images/meme-logo.png"

export default function MemeHeader(){
    return(
        <header>
                <div className="memeParentDiv">
                    <img src={memelogo} width="48px"/>
                    <div className="setText">Meme Generator</div>
                </div>
            </header>
    )
}