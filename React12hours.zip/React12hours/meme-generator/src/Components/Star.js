import React from "react";

export default function Star(props){
    return(
        <div>Star {props.markFaviourate ? "Marked": "Unmarked"}</div>
    )
}