import React from "react";
import mainImage from "../Images/main-meme.jpeg"
import memesData from "../memesData.js"

export default function MainMeme(){
    let [url, setUrl] = new React.useState("https://picsum.photos/id/237/200/300");
    function handleClick(){
        const random = Math.ceil( Math.random() * (5 - 1));
        var imageUrl = memesData.data.memes[random].url;
        setUrl(imageUrl);
        console.log(url);
    }
    return (
        <main>
                <div className="inputContainer">
                    <input type="text" placeholder="Enter top text" />
                    <input type="text" placeholder="Enter bottom text" />
                </div>
                <div className="buttonContainer">
                    <button onClick={handleClick}>Generate Meme!</button>
                </div>
                <div className="memeContainer">
                    <img src={url} />
                    <div className="topText">Top Text</div>
                    <div className="bottomText">Bottom Text</div>
                </div>
            </main>
    )
}