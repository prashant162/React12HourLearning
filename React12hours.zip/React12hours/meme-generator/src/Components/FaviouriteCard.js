import React from "react";
import image from "../Images/main-meme.jpeg"
import Star from "./Star"

export default function FaviourateCard(){
    const [cardInfo, setCardInfo] = new React.useState({
        "firstName": "John",
        "lastName": "Doe",
        "email": "johndoe@gmail.com",
        "position": "Senior Inspector",
        "isFaviourate": true
    });
    function setFaviourate(){
        setCardInfo(function(prevValue){
            return {
                ...prevValue,
                "isFaviourate" : !prevValue.isFaviourate
            }
        })
    }
    return(
        <>
            <img src={image} />
            <Star markFaviourate={cardInfo.isFaviourate} />
            <div>{cardInfo.firstName} {cardInfo.lastName}</div>
            <div>{cardInfo.position}</div>
            <div>{cardInfo.email}</div>
        </>
    )
}