import React from "react"; 

export default function ShowArray(){
    const [thingsArray, setThingsArray] = new React.useState(["Things 1","Things 2"]);
    function handleClick(){
        setThingsArray(prevValue => [...prevValue, `Things ${prevValue.length + 1}`])
    }
    return (
        <>
            {thingsArray.map(item => <p key={item}>{item}</p>)}

            <button onClick={handleClick}>Add Value</button>
        </>
    )
}