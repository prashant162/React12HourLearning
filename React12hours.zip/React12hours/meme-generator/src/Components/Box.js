import React from "react";

export default function Box(props){
    const aquamarine = props.on ? "box aquamarine" : "box";
    return(
        <div className={aquamarine} onClick={props.handleBoxClick}></div>
    )
}