export default [
    {
      id: 1,
      on: false,
    },
    {
      id: 2,
      on: true,
    },
    {
      id: 3,
      on: true,
    },
    {
      id: 4,
      on: false,
    },
    {
      id: 5,
      on: true,
    },
    {
      id: 6,
      on: false,
    }
  ];