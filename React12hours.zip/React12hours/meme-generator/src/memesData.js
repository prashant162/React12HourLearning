export default{
    "success": true,
    "data":{
        "memes":[
            {
                "id": "1223243",
                "name": "Hollywood clip",
                "url": "https://picsum.photos/id/237/200/300",
                "width": 1200,
                "height": 1200,
                "box_count": 2
            },
            {
                "id": "1223243",
                "name": "Hollywood clip",
                "url": "https://picsum.photos/200/300/?blur",
                "width": 1200,
                "height": 1200,
                "box_count": 2
            },
            {
                "id": "23452345",
                "name": "Round trip",
                "url": "https://picsum.photos/id/870/200/300?grayscale&blur=2",
                "width": 1200,
                "height": 1200,
                "box_count": 3
            },
            {
                "id": "242234",
                "name": "Treasure hunt",
                "url": "https://picsum.photos/200/300?grayscale",
                "width": 1200,
                "height": 1200,
                "box_count": 4
            },
            {
                "id": "56456",
                "name": "Lauging meme",
                "url": "https://picsum.photos/seed/picsum/200/300",
                "width": 1200,
                "height": 1200,
                "box_count": 5
            }
        ]
    }
}