import React, {useState} from "react";
import FormPractice from "./Components/FormPractice";
import SignUpForm from "./Components/SignUpForm";
import UseEffectChallenge from "./Components/UseEffectChallenge";
import WindowTracker from "./Components/WindowTracker";
import "./Styles/Styles.css"

export default function App(){
    const [show, setShow] = useState(true);
    function handleShowHide(){
        setShow(!show);
      }
    return(
        <>
        <FormPractice />
        <hr/>
        <SignUpForm />
        <hr />
        <UseEffectChallenge />
        <hr />
        <div style={{backgroundColor: "orange"}}>
        <button onClick={handleShowHide}>Press me to {show ? "hide" : "show"} window size</button>
            
        {
                show && <WindowTracker />
        }
        </div>
        <hr />
        </>
    )
}