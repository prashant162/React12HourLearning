import React, {useState, useEffect} from "react";

export default function WindowTracker(){
    
    
    const [resizeWidth, setResizeWidth] = useState(window.innerWidth);
    function setWidth(){
        setResizeWidth(window.innerWidth)
    }
    useEffect(function(){  
        console.log("mounting component");      
        window.addEventListener("resize", setWidth)
        //this below method is provided to un bind any event so that after unmounting 
        //any attached event as part of mounting the components were attached. 
        //This can be used in the example that if any chat applicatin is built and when
        //chat window is closed then its server connections also should be disconnected
        return function(){
            console.log("component hidden so unmounting it to save memory leak.");
            window.removeEventListener("resize", setResizeWidth)
        }
    }
    ,[])
    return(
            <div>Window Size: {resizeWidth}</div>
    )
}