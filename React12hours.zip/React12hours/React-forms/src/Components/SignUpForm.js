import React from "react";

export default function SignUpForm(){
    const [formData, setFormData] = React.useState(
        {
            email:"",
            password: "",
            confirmPassword: "",
            termsconditions: true,
            passwordMatch: true
        });
    function handleFormData(event){
        const {name, value, type, checked} = event.target
        setFormData(function(prevFormData){
            return {...prevFormData, 
                [name]: type == "checkbox" ? checked : value
            }
        })
    }

    function handleSubmit(event){
        event.preventDefault() //stop reload of the page
        //callAnApi(formData);
        if(formData.password == formData.confirmPassword){
            alert("password matched");
        }
        if(formData.password != formData.confirmPassword){
            alert("password do not match");
            return
        }
        if(formData.termsconditions){
            alert("sign up successful");
        }
    }
    return (
      <>
        <form onSubmit={handleSubmit}>
          <input
            value={formData.email}
            type="email"
            name="email"
            placeholder="Enter your email address..."
            onChange={handleFormData}
          />
          <br />

          <input
            value={formData.password}
            type="password"
            name="password"
            placeholder="Enter your password..."
            onChange={handleFormData}
          />
          <br />
          <input
            value={formData.confirmPassword}
            type="password"
            name="confirmPassword"
            placeholder="Confirm your password..."
            onChange={handleFormData}
          />
          <br />
          {!formData.passwordMatch && <div>Your password doesn't match</div>}
          <br />
          <label htmlFor="termsconditions">
            I agree the terms & conditions
          </label>
          <input
            id="termsconditions"
            value={formData.termsconditions}
            type="checkbox"
            name="termsconditions"
            onChange={handleFormData}
          />
          <br />
          <button>Submit</button>
        </form>

        <div>
          <h4>Below is the info that you entering</h4>
          password: {formData.password} <br />
          confirmPassword: {formData.confirmPassword} <br />
          email: {formData.email} <br />
        </div>
      </>
    );
}