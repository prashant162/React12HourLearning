import React, {useEffect, useState} from "react";

export default function UseEffectChallenge(){
    const [peopleData, setPeopleData] = useState({});
    const [count, setCount] = useState(1);
    console.log("component rendered")
    function handleClick(){
        setCount(count + 1)
    }
    React.useEffect(function(){
        console.log("effect run");
        fetch(`https://swapi.dev/api/people/${count}`)
            .then(res => res.json())
            .then(data => setPeopleData(data))
    },[count])
    return(
        <>
            <button onClick={handleClick}>Add</button>
            <h2>Result:</h2>
            <div>{JSON.stringify(peopleData)}</div>
        </>
    )
}