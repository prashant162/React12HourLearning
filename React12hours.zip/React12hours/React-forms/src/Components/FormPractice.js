import React from "react";

export default function FormPractice(){
    const [formData, setFormData] = React.useState(
        {
            firstName: "", 
            lastName: "", 
            email:"",
            comments: "",
            isFriendly: true,
            gender: "",
            birthCountry: ""
        });
    function handleFormData(event){
        const {name, value, type, checked} = event.target
        setFormData(function(prevFormData){
            return {...prevFormData, 
                [name]: type == "checkbox" ? checked : value
            }
        })
    }

    function handleSubmit(event){
        event.preventDefault() //stop reload of the page
        //callAnApi(formData);
    }
    return(
        <>
        <form onSubmit={handleSubmit}>
            <input value={formData.firstName} type="text" name="firstName" placeholder="Enter your first name..." onChange={handleFormData} /><br/>
            <input value={formData.lastName} type="text" name="lastName" placeholder="Enter your last name..." onChange={handleFormData} /><br/>
            <input value={formData.email} type="email" name="email" placeholder="Enter your email address..." onChange={handleFormData} /><br/>
            <textarea value={formData.comments} name="comments" onChange={handleFormData}></textarea><br/>
            <input value={formData.isFriendly} type="checkbox" name="isFriendly" onChange={handleFormData} /><br/>
            <label htmlFor="male">Male</label>
            <input id="male" type="radio" checked={formData.gender === "male"} value="male" name="gender" onChange={handleFormData} /><br/>
            <label htmlFor="female">Female</label>
            <input id="female" type="radio" checked={formData.gender === "female"} value="female" name="gender" onChange={handleFormData}/><br/>
            <label htmlFor="none">None</label>
            <input id="none" type="radio" checked={formData.gender === "none"} value="none" name="gender" onChange={handleFormData}/>
            <select id="birthCountry" value={formData.birthCountry} name="birthCountry" onChange={handleFormData}>
                <option value="">--choose--</option>
                <option value="India">India</option>
                <option value="USA">USA</option>
                <option value="Russia">Russia</option>
            </select>
            <button>Submit</button>
        </form>

<div>
firstName: {formData.firstName} <br />
firstName:  {formData.lastName} <br />
email:  {formData.email} <br />
comments:  {formData.comments} <br />
isFriendly: {formData.isFriendly} <br />
gender:  {formData.gender} <br />
birthCountry:  {formData.birthCountry}
    </div>
    </>
    )
}